.. -*- mode: rst -*-

=====
Demos
=====

This directory contains a new collection of examples or demos for using ``Svglib``
in different contexts. At the beginning this only contains an example app for
using it from Streamlit_. More will hopefully be added over time. Please feel
free to make suggestsions if you have something useful to share with others!

.. _Streamlit: https://streamlit.io
